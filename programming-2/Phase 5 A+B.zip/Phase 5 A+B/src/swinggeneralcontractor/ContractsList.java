/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swinggeneralcontractor;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

 
public class ContractsList extends javax.swing.JDialog {
    DefaultTableModel model=new DefaultTableModel();
    
    public ContractsList(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        
        refreshWindow();
    }
    
    public void refreshWindow(){
        DefaultTableModel model=new DefaultTableModel(){
            String[] columns=new String [] {
                "Contract Name", "Subcontractors ", "Hours Per Subcontractor", "Total Cost"
            } ;

            @Override 
            public int getColumnCount() { 
                return columns.length; 
            } 

            @Override 
            public String getColumnName(int index) { 
                return columns[index]; 
            } 
        };
        for (ContractModel allContract : JavaContractor.getINSTANCE().getAllContracts()) {
            String name=allContract.getContractName();  //Get name
            String hours="";    //Get all hours as a string
            for (Double double1 : allContract.getHoursPerEachSubcontractor()) {
                hours+=double1+",";
                
            }
            String subcont="";
            for (String string1 : allContract.getListContractors()) {
                subcont+=string1+",";
                
            }
            Double totalCost=allContract.getTotalCost();
            Vector v=new Vector();
            v.add(name);
            v.add(subcont);
            v.add(hours);
            v.add(totalCost);
            model.addRow(v);
        } 
        jTable1.setModel(model);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Contracts List");

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Contract Name", "Subcontractors ", "Hours Per Subcontractor", "Total Cost"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Double.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("Back");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Modify");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Delete");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 375, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 24, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        int i=jTable1.getSelectedRow();
        
        if(i==-1)
            return;
          
        String name=JOptionPane.showInputDialog("Enter new name");
        String subcont=JOptionPane.showInputDialog("Enter all subcontractors("+JavaContractor.getINSTANCE().getSubcontractorsNames()+"), separated by commas");
        String hours=JOptionPane.showInputDialog("Enter each hours per subcontractor("+JavaContractor.getINSTANCE().getContractHours(i)+"), separated by commas");
        Double totalCost=JavaContractor.getINSTANCE().getAllContracts().get(i).getTotalCost();
        
        ArrayList<String> su=new ArrayList<>(Arrays.asList(subcont.split(",")));//Convert comma sep string to list of strings
        ArrayList<String> hoursPerEachSubcontractorString=new ArrayList<>(Arrays.asList(hours.split(",")));//Convert comma sep string to list of strings
        ArrayList<Double> hoursPerEachSubcontractor=new ArrayList<>();
        for (String string : hoursPerEachSubcontractorString) {
            hoursPerEachSubcontractor.add(Double.parseDouble(string));
        }
        JavaContractor.getINSTANCE().getAllContracts().set(i,new ContractModel(name, su, hoursPerEachSubcontractor));
        //
        refreshWindow(); 
      
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        int i=jTable1.getSelectedRow();
        
        if(i==-1)
            return;
        JavaContractor.getINSTANCE().getAllContracts().remove(i);
        refreshWindow();
    }//GEN-LAST:event_jButton3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ContractsList dialog = new ContractsList(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
