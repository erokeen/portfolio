/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swinggeneralcontractor;

 
public class SubcontractorModel {
    private String subcontractorName;
    private double costPerHour;
    private int mainSpecialty;

    public SubcontractorModel(String subcontractorName, double costPerHour, int mainSpecialty) {
        this.subcontractorName = subcontractorName;
        this.costPerHour = costPerHour;
        this.mainSpecialty = mainSpecialty;
    }

    public String getSubcontractorName() {
        return subcontractorName;
    }

    public double getCostPerHour() {
        return costPerHour;
    }

    public int getMainSpecialty() {
        return mainSpecialty;
    }

    public void setSubcontractorName(String subcontractorName) {
        this.subcontractorName = subcontractorName;
    }

    public void setCostPerHour(double costPerHour) {
        this.costPerHour = costPerHour;
    }

    public void setMainSpecialty(int mainSpecialty) {
        this.mainSpecialty = mainSpecialty;
    }
    
    
}
