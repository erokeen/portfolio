/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package swinggeneralcontractor;

import java.util.ArrayList;

 
public class ContractModel {
    private String contractName;
    private ArrayList<String> listContractors;
    private ArrayList<Double> hoursPerEachSubcontractor;    
    
    
    private double totalCost;       

    public ContractModel(String contractName, ArrayList<String> listContractors, ArrayList<Double> hoursPerEachSubcontractor) {
        this.contractName = contractName;
        this.listContractors = listContractors;
        this.hoursPerEachSubcontractor=hoursPerEachSubcontractor;
        this.totalCost=this.getTotalCost();
        
    }
    
    public ContractModel() {
        this.contractName = "";
        this.listContractors = new ArrayList<>();
        this.hoursPerEachSubcontractor=new ArrayList<>();
    }
   
    public String getContractName() {
        return contractName;
    }

    public ArrayList<String> getListContractors() {
        return listContractors;
    }

    public ArrayList<Double> getHoursPerEachSubcontractor() {
        return hoursPerEachSubcontractor;
    }

    public double getTotalCost() {
        totalCost=0;
        int size=listContractors.size();//Size of how many subcontractors there are in this contract
        for (int i = 0; i < size; i++) {
            String elementSubcontractor=listContractors.get(i);
            Double elementHours=hoursPerEachSubcontractor.get(i);
             
            totalCost+=JavaContractor.getINSTANCE().findByName(elementSubcontractor).getCostPerHour()*elementHours;
        }
        return totalCost;
    }

    public void setContractName(String contractName) {
        this.contractName = contractName;
    }

    public void setListContractors(ArrayList<String> listContractors) {
        this.listContractors = listContractors;
    }

    public void setHoursPerEachSubcontractor(ArrayList<Double> hoursPerEachSubcontractor) {
        this.hoursPerEachSubcontractor = hoursPerEachSubcontractor;
    }

    @Override
    public String toString() {
        String list1="";
        for (String listContractor : listContractors) {
            list1+=listContractor+",";
        }
        String list2="";
        for (Double hours : hoursPerEachSubcontractor) {
            list2+=hours+",";
        }
        return "ContractName=" + contractName + " subcontractors=[ " + list1 + "] hours=[" + list2 + "] totalCost=" + totalCost;
    }
    
    
}
