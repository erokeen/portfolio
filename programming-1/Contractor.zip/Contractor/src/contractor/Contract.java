/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contractor;

import java.util.ArrayList;

/**
 *
 * @author metudoreanu
 */
public class Contract {
    String name;
    ArrayList<Subcontractor> subs;
    ArrayList<Double> hours;
    
    public Contract(){
        subs = new ArrayList<>();
        hours = new ArrayList<>();
    }
    
    @Override
    public String toString(){
        String msg = name + " [";
        
        //add the names of each subcontractor
        for(int i = 0; i < subs.size(); i++){
            Subcontractor s = subs.get(i);
            msg = msg + s.getName() + ", ";
        }
        msg = msg + "]";
        msg = msg + " " + computeTotalCost();
        return msg;
    }
    
    //get the hours contractor s is supposed to work
    public double getHours(Subcontractor s){
        int index = subs.indexOf(s);
        if(index != -1)
            return getHours(index);
        else
            return 0; //in case contractor s is not part of this contract
    }
   
    //get the hours for the subcontractor at a given index
    public double getHours(int index){
        return hours.get(index);
    }
    
    public int getContractorCount(){
        return subs.size();
    }
    
    public Subcontractor getContractor(int index){
        return subs.get(index);
    }
    
    //change the hours for a given subcontractor
    public void changeHours(Subcontractor s, double newHours){
        int index = subs.indexOf(s);
        if(index != -1)
            changeHours(index, newHours);
    }
    
    //change the hours for the subcontractor at position index
    public void changeHours(int index, double newHours){
        hours.set(index, newHours); //hours[index] = newHours
    }
    
    //removes a given subcontractor
    public void removeContractor(Subcontractor s){
        int index = subs.indexOf(s);
        if(index != -1)
            removeContractor(index);
    }
    

    
    //removes subcontractor at position index (and its hours)
    public void removeContractor(int index){
        subs.remove(index);
        hours.remove(index);
    }
    
    public void addContractor(Subcontractor s, double howManyHours){
        //check if the subcontractor is already part of the contract
        if(subs.contains(s))
            return; //get out of this function, and ignore the add
        
        //check if the number of hours makes sense
        if(howManyHours <= 0)
            return; //get out of this function, and ignore the add
        
        //if the program gets to this point, everything should be fine with the add
        subs.add(s);
        hours.add(howManyHours);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    
    public double computeTotalCost(){
        double total = 0;
        
        for(int i = 0; i < subs.size(); i++){
            Subcontractor s = subs.get(i); // get the i-th contractor
            double h = hours.get(i); //get the i-th number of hours
            
            total = total + s.getCostPerHour() * h;
        }
        
        return total;
    }
    
    
}
