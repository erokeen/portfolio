/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contractor;
import java.util.ArrayList;

import javax.swing.JFrame;

/**
 *
 * @author metudoreanu
 */
public class Contractor {
    
    static ArrayList<Contract> contracts = new ArrayList<>();
    static ArrayList<Subcontractor> subcontractors = new ArrayList<>();
    
    static ContractPanel contractPanel; 
    static SubcontractorPanel subPanel;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     
        //example of creating a contract
        //start by making a few contractors
        Subcontractor a, b, k, e, g, h;
       
        
        a = new Subcontractor();
        a.setName("ABC electric");
        a.setCostPerHour(62);
        a.setSpecialty("electrical");
        
        subcontractors.add(a);
        
        b = new Subcontractor();
        b.setName("JDK");
        b.setCostPerHour(0.2);
        b.setSpecialty("code development");
        
        subcontractors.add(b);
        
        k = new Subcontractor();
        k.setName("Plub");
        k.setCostPerHour(20);
        k.setSpecialty("Plumbing");
        
        subcontractors.add(k);
        
        e = new Subcontractor();
        e.setName("Decoding");
        e.setCostPerHour(33);
        e.setSpecialty("Decoder");
        
        subcontractors.add(e);
        
        g = new Subcontractor();
        g.setName("Water");
        g.setCostPerHour(6);
        g.setSpecialty("Water");
        
        subcontractors.add(g);
        
        h = new Subcontractor();
        h.setName("Gas");
        h.setCostPerHour(11);
        h.setSpecialty("gas");
        
        subcontractors.add(h);
        
          //now make a contract
        Contract d = new Contract();
        d.setName("Highschool");
        d.addContractor(a, 12); //add contractor a for 12 hours
        d.addContractor(b, 230); //add contractor b for 230 hours
        d.addContractor(k, 20);
        //done with creation
        
        contracts.add(d);
        
        Contract j = new Contract();
        j.setName("University");
        j.addContractor(e, 12);
        j.addContractor(g, 44);
        j.addContractor(h, 53);
        
        contracts.add(j);
        
        Contract t = new Contract();
        t.setName("Elementary");
        t.addContractor(g, 12);
        t.addContractor(b, 90);
        t.addContractor(a, 200);
        
        contracts.add(t);
        
        for(int u = 0; u < 1; u++){
        //printing contract information
        System.out.println("Contract " + d.getName() + " has a total of cost of $" +
                d.computeTotalCost() + " and the following subs:");
        //need a loop to go through all contractors
        for(int i = 0; i < d.getContractorCount(); i++){
            Subcontractor s = d.getContractor(i); //get the i-th sub
            System.out.println("\t" + s.getName() + " (" + s.getSpecialty() + ")" +
                    " for " + d.getHours(i) + " hours at $" + s.getCostPerHour());
        }
        
        System.out.println("");
        
        System.out.println("Contract " + j.getName() + " has a total of cost of $" +
                j.computeTotalCost() + " and the following subs:");
        for(int i = 0; i < j.getContractorCount(); i++){
            Subcontractor s = j.getContractor(i); //get the i-th sub
            System.out.println("\t" + s.getName() + " (" + s.getSpecialty() + ")" +
                    " for " + j.getHours(i) + " hours at $" + s.getCostPerHour());
        }
        
        System.out.println("");
        
        System.out.println("Contract " + t.getName() + " has a total of cost of $" +
                t.computeTotalCost() + " and the following subs:");
        for(int i = 0; i < t.getContractorCount(); i++){
            Subcontractor s = t.getContractor(i); //get the i-th sub
            System.out.println("\t" + s.getName() + " (" + s.getSpecialty() + ")" +
                    " for " + t.getHours(i) + " hours at $" + s.getCostPerHour());
        }
        
        }
        
        JFrame f1 = new JFrame("Subcontractors");
        f1.setSize(500, 500);
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        subPanel = new SubcontractorPanel();
                
        f1.add(subPanel);
        f1.setVisible(true);
        
        JFrame f2 = new JFrame("Contracts");
        f2.setSize(800, 600);
        f2.setLocation(200, 200);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        contractPanel = new ContractPanel();
        
        f2.add(contractPanel);
        f2.setVisible(true);
    }
    
}
