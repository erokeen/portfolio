/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contractor;

/**
 *
 * @author metudoreanu
 */
public class Subcontractor {
    private String name;
    private double costPerHour;
    private String specialty;
    
    public Subcontractor(){
        name = "Name";
        costPerHour = 0;
        specialty = "Builder";
    }
    
    @Override
    public String toString(){
        String ret = name;
        ret = ret + " (" + specialty + ")"; // add specialty
        ret = ret + " $" + costPerHour;
        return ret;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCostPerHour() {
        return costPerHour;
    }

    public void setCostPerHour(double costPerHour) {
        this.costPerHour = costPerHour;
    }

    public String getSpecialty() {
        return specialty;
    }

    public void setSpecialty(String specialty) {
        this.specialty = specialty;
    }
    
    
    
}
